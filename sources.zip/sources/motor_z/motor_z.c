// MOTOR Z


// Including the required libraries

#include <stdio.h> // stdio. h is a header file which has the necessary information to include 
//the input/output related functions in our program. 
#include <stdlib.h> // header of the general purpose standard library of C programming language 
//which includes functions involving memory allocation, process control, conversions and others. 
#include <fcntl.h> // header in the C POSIX library for the C programming language that contains constructs that refer to file control, e.g. opening a file, retrieving and changing the permissions 
//of file, locking a file for edit, etc.
#include <sys/stat.h> // functions that have arguments or return values of type mode_t, so that symbolic values for that type can be used
#include <sys/types.h> // defines data types used in system source code
#include <unistd.h> // header file that provides access to the POSIX operating system API 
#include <signal.h> // header file defined in the C Standard Library to specify how a program handles signals while it executes.
#include <time.h> // header file contains definitions of functions to get and manipulate date and time information>

/* POSITION X : 
    MINIMUM = 0
    MAXIMUM = 5 */
float z = 0;

int cmd,val;

//Variable for the log file

//Function to increase/decrease position with step = 0.5
//double error = (float) float() /(float) (RAND_MAX/0.001);
float random_float(float a, float b){
    return (((float) rand())/ ((float) RAND_MAX)) * (b-a) + a;    //why random generator?- for errors
}
void execute_command(){

    if (cmd == 3) {
        if (z < 5){
            z += random_float(-0.1, 0.1);
            z += 0.1;
        } else {
            cmd = 0;
        }
    } else if (cmd == 4) {
        if (z > 0){
            z += random_float(-0.1, 0.1);
            z -= 0.1;
        } else {
            cmd = 0;
        }
    }

}

//Function to handle signals (STOP and RESET)
void handle_sigusr1(int sig){
    if (sig == SIGUSR1) {
        cmd = 4;
    }
    if (sig == SIGUSR2) {
        cmd = 6;
        
    }
}

//Function that returns a random float in the interval [a,b]


// main ()
// argc stands for argument count and argv stands for argument values. These are variables passed to the main function when it starts executing.
// main() in which we developed the principal code of the MOTOR Z.
int main(int argc, char * argv[]){


    //Get watchdog PID
    int pid_watchdog = atoi(argv[1]);

    //Register signals
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler=&handle_sigusr1;
    sa.sa_flags=SA_RESTART;
    sigaction(SIGUSR1, &sa, NULL);
    sigaction(SIGUSR2,&sa,NULL);
    //Opening FIFOs
    int command_z, posmotor_z;    
    if ((command_z = open("/tmp/command_z", O_RDONLY)) < 0) {
        perror("MOTOR z: Error opening cmd z ");
        return 1;
    }
    if ((posmotor_z = open("/tmp/posmotor_z", O_WRONLY)) < 0) {
        perror("MOTOR z: Error opening pos z ");
        return 1;
    }


    //VARIABLES FOR SELECT
    fd_set fds;
    int retval;
    struct timeval tv;
    tv.tv_sec = 0;
    tv.tv_usec = 0;

    while(1){
        
        //Reads new command from FIFO if there is a new command
        FD_ZERO(&fds);
        FD_SET(command_z, &fds);
        retval = select(FD_SETSIZE, &fds, NULL, NULL, &tv);
        if (retval < 0) {
            perror("MOTOR z: Error in select");
        } else if (retval > 0) {
            if (FD_ISSET(command_z, &fds)) {
                //reading command from FIFO
                read(command_z, &cmd, sizeof(cmd));
            }
        }

        //Increase/decrease position or stops if limit has been reached
        execute_command();

        //If it's moving sends a signal to watchdog and write new position
            //without exceeding the limit of the axes
        if (z > 5){
               z= 5;
             }
        if (z < 0){
               z=0;
            }            
            write(posmotor_z, &z, sizeof(z));
        sleep(1);
    
   }
    close(command_z);
    close(posmotor_z);
} // end of main ()
