// WATCHDOG


// Including all the needed libraries.

#include <stdio.h> // stdio. h is a header file which has the necessary information to include 
//the input/output related functions in our program. 
#include <stdlib.h> // header of the general purpose standard library of C programming language 
//which includes functions involving memory allocation, process control, conversions and others. 
#include <fcntl.h> // header in the C POSIX library for the C programming language that contains constructs that refer to file control, e.g. opening a file, retrieving and changing the permissions 
//of file, locking a file for edit, etc.
#include <errno.h> // defines macros for reporting and retrieving error conditions using the symbol errno (short for "error number").
#include <sys/types.h> // defines data types used in system source code
#include <sys/stat.h> // functions that have arguments or return values of type mode_t, so that symbolic values for that type can be used
#include <unistd.h> // header file that provides access to the POSIX operating system API 
#include <signal.h> // header file defined in the C Standard Library to specify how a program handles signals while it executes.
#include <string.h> // the predefined functions which are designed to handle strings
#include <termios.h> // contains the definitions used by the terminal I/O interfaces (see the XBD specification, General Terminal Interface for the structures and names defined).
#include <time.h> // header file contains definitions of functions to get and manipulate date and time information
#include <sys/wait.h> // header defines the following symbolic constants for use with waitpid(): WNOHANG: Do not hang if no status is available, return immediately.

// The CHECK(X) function is usefull to write on shell whenever a system call return an error.
// The function will print the name of the file and the line at which it found the error.
// It will end the check exiting with code 1.


// Declaring PIDs of each process, used for Signals

pid_t pid_motor_x;
pid_t pid_motor_z;
pid_t pid_command;

// Declaring the pipe

int fd_c_to_wd;

// In this section of the code we handle Signals coming directly from Command Console and Inspection Console. Everytime we press a key (X increase/decrease/stop - Z increase/decrease/stop -
// Emergency Stop Button - Emergency Reset Button) we send a Signal to the watchdog that will
// make the alarm() counter restart. This counter is needed in order to disable the Command Console
// and reset the hoist's positions let's say 60 seconds (of inactivity)

void handler(int sig){

	if(sig == SIGUSR1){

		alarm(60);
	}
	
	// This SIGALRM is directly sent by the watchdog process itself. In case we do not
	// press any button, since the opening of the Command and Inspection Console, the alarm counter put
	// in the main will go to 0. After that the SIGALRM will be sent and, through Signals
	// we will: 1) Make motor x reset 2) Make motor z reset 3) Disable the Command Console

	if(sig == SIGALRM){

		kill(pid_motor_x, SIGUSR2);
		kill(pid_motor_z, SIGUSR2);
		kill(pid_command, SIGUSR2);
	}
}

// main ()
// argc stands for argument count and argv stands for argument values. These are variables passed to the main function when it starts executing.
// main() in which we developed the principal code of the Watchdog.
int main(int argc, char * argv[]){

	// Opening the pipes

	// argv[1] is the second argument passed to the main from the master process 

        if ((fd_c_to_wd = open("/tmp/cwd", O_RDONLY)) < 0) {
        perror("Error opening cwd ");
        return 1;
    }
        fd_c_to_wd=open(argv[1], O_RDONLY);
	// We convert the motors' pid thanks to atoi--> from string to integer
	// argv[2/3] are the third/fourth arguments passed to the main from the master process (see master process
	// for detailed explenation) 

	pid_motor_x = atoi(argv[2]);
	pid_motor_z = atoi(argv[3]);

	// Declaring for the use of Signals. 
	
	struct sigaction sa;
	memset(&sa, 0, sizeof(sa));
	sa.sa_handler=&handler;
	sa.sa_flags=SA_RESTART;
	

	// If no input from user end since the opening of the Consoles, the alarm will go to 0;
	
	alarm(60);
	
	sigaction(SIGUSR1, &sa, NULL);
	sigaction(SIGALRM,&sa,NULL);

	// Read the pid of commmand.c
	
	read(fd_c_to_wd, &pid_command, sizeof(pid_command));
	
	// 

	while(1){
		
		sleep(1);
	}

	// closing pipe

	close(fd_c_to_wd);

	return 0;
} // end of main ()
