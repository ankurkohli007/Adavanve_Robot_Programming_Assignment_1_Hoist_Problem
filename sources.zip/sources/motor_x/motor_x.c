// MOTOR X


// Including the required libraries

#include <stdio.h> // stdio. h is a header file which has the necessary information to include 
//the input/output related functions in our program. 
#include <stdlib.h> // header of the general purpose standard library of C programming language 
//which includes functions involving memory allocation, process control, conversions and others. 
#include <fcntl.h> // header in the C POSIX library for the C programming language that contains constructs that refer to file control, e.g. opening a file, retrieving and changing the permissions 
//of file, locking a file for edit, etc.
#include <sys/stat.h> // functions that have arguments or return values of type mode_t, so that symbolic values for that type can be used
#include <sys/types.h> // defines data types used in system source code
#include <unistd.h> // header file that provides access to the POSIX operating system API 
#include <signal.h> // header file defined in the C Standard Library to specify how a program handles signals while it executes.
#include <time.h> // header file contains definitions of functions to get and manipulate date and time information>

/* POSITION X : 
    MINIMUM = 0
    MAXIMUM = 5 */
float x = 0;

int cmd,val;

//random number generator for error generation
float random_float(float a, float b){
    return (((float) rand())/ ((float) RAND_MAX)) * (b-a) + a;   
}


void execute_command(){
    if (cmd == 1) {
        if (x < 5){
            x += random_float(-0.1, 0.1);
            x += 0.1;
        } else {
            cmd = 0;
        }
    } else if (cmd == 2) {
        if (x > 0){
            x += random_float(-0.1, 0.1);
            x -= 0.1;
        } else {
            cmd = 0;
        }
    }

}

//Function to handle signals (STOP and RESET)
void handle_sigusr1(int sig){
    if (sig == SIGUSR1) {
        cmd = 5;
    }
    if (sig == SIGUSR2) {
        cmd = 2;
        
    }
}


//Function that returns a random float in the interval [a,b]


// main ()
// argc stands for argument count and argv stands for argument values. These are variables passed to the main function when it starts executing.
// main() in which we developed the principal code of the MOTOR X.
int main(int argc, char * argv[]){
 
    
    //Get watchdog PID
    int pid_watchdog = atoi(argv[1]);

    //Register signals
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler=&handle_sigusr1;
    sa.sa_flags=SA_RESTART;
    sigaction(SIGUSR1, &sa, NULL);
        sigaction(SIGUSR2,&sa,NULL);
    //Opening FIFOs
    int command_x, posmotor_x;    
    if ((command_x = open("/tmp/command_x", O_RDONLY)) < 0) {
        perror("MOTOR X: Error opening cmd x ");
        return 1;
    }
    if ((posmotor_x = open("/tmp/posmotor_x", O_WRONLY)) < 0) {
        perror("MOTOR X: Error opening pos x ");
        return 1;
    }


    //VARIABLES FOR SELECT
    fd_set fds;
    int retval;
    struct timeval tv;
    tv.tv_sec = 0;
    tv.tv_usec = 0;

    while(1){
        //Reads new command from FIFO if there is a new command
        FD_ZERO(&fds);
        FD_SET(command_x, &fds);
        retval = select(FD_SETSIZE, &fds, NULL, NULL, &tv);
        if (retval < 0) {
            perror("MOTOR X: Error in select");
        } else if (retval > 0) {
            if (FD_ISSET(command_x, &fds)) {
                //reading command from FIFO
                read(command_x, &cmd, sizeof(cmd));
            }
        }

        //Increase/decrease position or stops if limit has been reached
        execute_command();

        //If it's moving sends a signal to watchdog and write new position
            //without exceeding the limit of the axes
        if (x > 5){
               x= 5;
             }
        if (x < 0){
               x=0;
            }            
            write(posmotor_x, &x, sizeof(x));
        sleep(1);
    }

    close(command_x);
    close(posmotor_x);
}// end of main()
