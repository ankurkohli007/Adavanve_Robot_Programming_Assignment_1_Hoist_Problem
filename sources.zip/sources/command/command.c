// COMMAND CONSOLE


// Including all the needed libraries.

#include <stdio.h> // stdio. h is a header file which has the necessary information to include 
//the input/output related functions in our program. 
#include <stdlib.h> // header of the general purpose standard library of C programming language 
//which includes functions involving memory allocation, process control, conversions and others. 
#include <fcntl.h> // header in the C POSIX library for the C programming language that contains constructs that refer to file control, e.g. opening a file, retrieving and changing the permissions 
//of file, locking a file for edit, etc.
#include <errno.h> // defines macros for reporting and retrieving error conditions using the symbol errno (short for "error number").
#include <sys/types.h> // defines data types used in system source code
#include <sys/stat.h> // functions that have arguments or return values of type mode_t, so that symbolic values for that type can be used
#include <unistd.h> // header file that provides access to the POSIX operating system API 
#include <signal.h> // header file defined in the C Standard Library to specify how a program handles signals while it executes.
#include <string.h> // the predefined functions which are designed to handle strings
#include <termios.h> // contains the definitions used by the terminal I/O interfaces (see the XBD specification, General Terminal Interface for the structures and names defined).
#include <time.h> // header file contains definitions of functions to get and manipulate date and time information
#include <sys/wait.h> // header defines the following symbolic constants for use with waitpid(): WNOHANG: Do not hang if no status is available, return immediately.

// In "command.c", handler() function is used in order to handle Signals coming from different processes. Like so we can disable the Command Console during the reset procedure and restart it once it 
//finished the reset routine. 

int k = 0;

void handler(int sig){

	if(sig == SIGUSR2){
		
		// Resetting the system

		k = 1;
		printf( "\nSYSTEM RESETTING! \n");
	}

	if(sig == SIGUSR1){

		// System works again

		k = 0;
	}
} 

// main ()
// argc stands for argument count and argv stands for argument values. These are variables passed to the main function when it starts executing.
// main() in which we developed the principal code of the command Console.
int main(int argc, char *argv[])
{
	// We had put this structure code just to avoid pressing 
	// "Enter" every time when user want to increase/decrease motors x and z of our hoist
    // the terminal referred to by the first argument and store them in 
    // the termios structure referenced by the second argument.

     printf("First Assignment for Adavance and Robot Programming (ARP) architecture designed by Ankur Kohli and Aatheethyaa Dhanasekaran\n");
    printf("COMMAND CONSOLE, please press the required commands to perform the operations\n");
    printf("\n");
    printf("To move UP, please press W\n");
    printf("To move DOWN, please press S\n");
    printf("To move RIGHT, please press D\n");
    printf("To move LEFT, please press A\n");
    printf("To STOP z axis, please press Z\n");
    printf("To STOP x axis, please press X\n");
    printf("Press E if you want to terminate programs execution\n");
    printf("\n");
	
    
  
	// In this part we have declared some varibales usefull in the code.

	// Declaring int for pipes.

    int fd_to_mx;
    int fd_to_mz;
    int fd_to_wd;
    int fd_to_insp;

	// Declaring variables used for select().

    int d = 1;
    int a = 2;
    int w = 3;
    int s = 4;
    int x = 5;
    int z = 6;
    
	// Declaring pid of watchdog and command.

    pid_t pid_wd;
    pid_t pid_command;
    
    char c;
    
	// Declaring for the use of Signals.

    struct sigaction sa; 
    
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler=&handler;
    sa.sa_flags=SA_RESTART;
    sigaction(SIGUSR2, &sa, NULL);
    sigaction(SIGUSR1, &sa, NULL);

	// We convert the watchdog's pid using "atoi"--> from string to integer
	// argv[1] is the second argument passed to the main from the master process (see master process
	// for detailed explenation)
    
    pid_wd = atoi(argv[1]);

	// Getting pid of the command, sending it to watchdog and inspection
	// just for using Signals.

    pid_command = getpid();
    
    // opens pipes to write the commands 
	//pipe to motor_x
    if ((fd_to_mx = open("/tmp/command_x", O_WRONLY)) < 0) {
        perror("Error opening cmd x ");
        return 1;
    }
	//pipe to motor_z
    if ((fd_to_mz = open("/tmp/command_z", O_WRONLY)) < 0) {
        perror("Error opening cmd z ");
        return 1;
    }
	//pipe to watchdog
    if ((fd_to_wd = open("/tmp/cwd", O_WRONLY)) < 0) {
        perror("Error opening cmd x ");
        return 1;
    }
	//pipe to inspection
    if ((fd_to_insp = open("/tmp/comm_ins", O_WRONLY)) < 0) {
        perror("Error opening cmd z ");
        return 1;
      }
	// Writing command pid to watchdog and inspection

    write(fd_to_wd, &pid_command, sizeof(pid_command));
	write(fd_to_insp, &pid_command, sizeof(pid_command));
	

	// Key reading loop: entering the loop of putting char from keyboard, without exit from program (no return in infinite while loop) 
	
	while ((c = getchar()) != 'e'){

		// Function getchar() to get the button pressed on the keyboard
		// If "e" is pressed,exit the while loop and the program terminate successfully.
		// Then master kills other processes
		
		// Through the use of "k" we can understand in which state we are.
		// if we are in the reset state (case 1), the system is resetting and no command can be
		// insert, except for the q command---> stop command (in case we have to stop the system in an EMERGENCY
		// during the resetting routine), until the reset has terminated. Indeed in case 0 we are in the normal situation in which 
		// we can use the Command Console, checking through a switch() which button we have entered on the keyboard.

		
    // initializing switch case
		switch(k){
		
			case 1:
				printf("command console stopped\n");
				fflush(stdout);
	        break;
	        
			// In the case 0 (normal situation) beyond printing some stuffs, we send a Signal
			// to the watchdog (VERY IMPORTANT) in orhter to reset the timer of the alarm, thanks to
			// after 60 seconds the command console will be disabled.

			case 0:

			// initializing switch case for motor operations	
	        	switch(c){

				    case 'w': // case w
						printf("Motor position increase in Z axes\n");
						fflush(stdout);
						write(fd_to_mz, &w, sizeof(c));
					        kill(pid_wd, SIGUSR1);
				    break;

				    case 's': // case s
						printf("Motor position decrease in Z axes\n");
						fflush(stdout);
						write(fd_to_mz, &s, sizeof(c));
						kill(pid_wd, SIGUSR1);
						
				    break;

				    case 'z' :// case z
						printf("stop z axes movement\n");
						fflush(stdout);
						write(fd_to_mz, &z, sizeof(c));
						kill(pid_wd, SIGUSR1);
				    break;
						
				    case 'd': // case d
						printf("Motor position increase in X axes\n");
						fflush(stdout);
						write(fd_to_mx, &d, sizeof(c));
						kill(pid_wd, SIGUSR1);
				    break;

				    case 'a': // case a
						printf("Motor position decrease in X axes\n");
						fflush(stdout);
						write(fd_to_mx, &a, sizeof(c));
						kill(pid_wd, SIGUSR1);
						
				    break;

				    case 'x': // case x
						printf("stop X axes movement\n");
						fflush(stdout);
						write(fd_to_mx, &x, sizeof(c));
						kill(pid_wd, SIGUSR1);
				    break;
					
					
				} 
			break;
		}
	}

	
	// Closing pipes

	close(fd_to_mx);
	close(fd_to_mz);
	close(fd_to_wd);
	close(fd_to_insp);

	return 0;

}// end of main()
